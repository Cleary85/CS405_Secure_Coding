// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <type_traits>  // std::is_integral, std::is_floating_point
#include <string>       // std::string
#include <cmath>        // std::isfinite
#include <typeinfo>     // typeid

template <typename T>
struct Result {
    T value;
    bool success;
    Result(T val, bool ok) : value(val), success(ok) {}
};


template <typename T>
Result<T> add_numbers(T const& start, T const& increment, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {   // if statement to catch integer types
        if (std::is_integral<T>::value)
        {   // catch over and then under flows
            if ((increment > 0) && (result > std::numeric_limits<T>::max() - increment))
                return Result<T>(T(), false); // overflow
            if ((increment < 0) && (result < std::numeric_limits<T>::min() - increment))
                return Result<T>(T(), false); // underflow
        }

        result += increment;
        // if statement to catch floating point types
        if (std::is_floating_point<T>::value)
        {
            if (!std::isfinite(result)) // overflow/underflow/NaN
                return Result<T>(T(), false);
        }
    }

    return Result<T>(result, true);
}


template <typename T>
Result<T> subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps)
{
    T result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {   // if statement to catch integer types
        if (std::is_integral<T>::value)
        {   // catch over and then under flows
            if ((decrement > 0) && (result < std::numeric_limits<T>::min() + decrement))
                return Result<T>(T(), false); // underflow
            if ((decrement < 0) && (result > std::numeric_limits<T>::max() + decrement))
                return Result<T>(T(), false); // overflow
        }

        result -= decrement;
        // if statement to catch floating point types
        if (std::is_floating_point<T>::value)
        {
            if (!std::isfinite(result))
                return Result<T>(T(), false);
        }
    }

    return Result<T>(result, true);
}

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    const unsigned long int steps = 5;
    const T increment = std::numeric_limits<T>::max() / steps;
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    Result<T> result = add_numbers<T>(start, increment, steps);
    if (result.success)
        std::cout << +result.value << std::endl;
    else
        std::cout << "Overflow Detected!" << std::endl;

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    result = add_numbers<T>(start, increment, steps + 1);
    if (result.success)
        std::cout << +result.value << std::endl;
    else
        std::cout << "Overflow Detected!" << std::endl;
}

template <typename T>
void test_underflow()
{
    // START DO NOT CHANGE
    const unsigned long int steps = 5;
    const T decrement = std::numeric_limits<T>::max() / steps;
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tSubtracting Numbers Without Overflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    Result<T> result = subtract_numbers<T>(start, decrement, steps);
    if (result.success)
        std::cout << +result.value << std::endl;
    else
        std::cout << "Underflow Detected!" << std::endl;

    std::cout << "\tSubtracting Numbers With Overflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    result = subtract_numbers<T>(start, decrement, steps + 1);
    if (result.success)
        std::cout << +result.value << std::endl;
    else
        std::cout << "Underflow Detected!" << std::endl;
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // signed integers
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // unsigned integers
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // real numbers
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Undeflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // signed integers
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // unsigned integers
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // real numbers
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}


int main()
{
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    do_overflow_tests(star_line);
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}
